<?php

declare(strict_types=1);

namespace Casbin\Exceptions;

/**
 * Class BatchOperationException.
 *
 * @author 1115610574@qq.com
 */
class BatchOperationException extends CasbinException
{
}
