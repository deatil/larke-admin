<?php


namespace Casbin\Exceptions;


class EvalFunctionException extends CasbinException
{

}
