<?php

declare(strict_types=1);

namespace Casbin\Exceptions;

/**
 * Class InvalidFilterTypeException.
 *
 * @author techlee@qq.com
 */
class InvalidFilterTypeException extends CasbinException
{
}
