<?php

declare(strict_types=1);

namespace Casbin\Exceptions;

/**
 * Class CannotSaveFilteredPolicy.
 *
 * @author techlee@qq.com
 */
class CannotSaveFilteredPolicy extends CasbinException
{
}
