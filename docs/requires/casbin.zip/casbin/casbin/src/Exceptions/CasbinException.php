<?php

declare(strict_types=1);

namespace Casbin\Exceptions;

/**
 * Class CasbinException.
 *
 * @author techlee@qq.com
 */
class CasbinException extends \Exception
{
}
