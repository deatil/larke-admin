<?php

declare(strict_types=1);

namespace Casbin\Exceptions;

/**
 * Class InvalidFilePathException.
 *
 * @author techlee@qq.com
 */
class InvalidFilePathException extends CasbinException
{
}
