<?php

declare(strict_types=1);

namespace Casbin\Exceptions;

/**
 * Class NotImplementedException.
 *
 * @author techlee@qq.com
 */
class NotImplementedException extends CasbinException
{
}
